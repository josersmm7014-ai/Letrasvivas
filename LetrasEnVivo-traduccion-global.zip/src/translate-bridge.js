import { registerPlugin } from '@capacitor/core';
const LocalTranslate = registerPlugin('LocalTranslate');
window.LV = window.LV || {};
window.LV.LocalTranslate = LocalTranslate;
