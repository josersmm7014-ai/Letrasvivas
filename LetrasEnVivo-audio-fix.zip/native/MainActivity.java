package com.letras.envivo;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override
  public void onCreate(Bundle savedInstanceState) {
    registerPlugin(MusicScanPlugin.class);
    registerPlugin(LocalTranslatePlugin.class);
    super.onCreate(savedInstanceState);
    getBridge().getWebView().addJavascriptInterface(new Object() {
      @JavascriptInterface
      public void keepAwake(final boolean on) {
        runOnUiThread(new Runnable() {
          public void run() {
            if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
          }
        });
      }

      @JavascriptInterface
      public void openNotifSettings() {
        runOnUiThread(new Runnable() {
          public void run() {
            try {
              Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
              i.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
              startActivity(i);
            } catch (Exception e) {
              Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
              i.setData(android.net.Uri.parse("package:" + getPackageName()));
              startActivity(i);
            }
          }
        });
      }
    }, "LVNative");
  }
}
