package com.letras.envivo;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.languageid.LanguageIdentification;
import com.google.mlkit.nl.languageid.LanguageIdentifier;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;
import com.google.mlkit.nl.translate.Translation;

@CapacitorPlugin(name = "LocalTranslate")
public class LocalTranslatePlugin extends Plugin {
  @PluginMethod
  public void translate(PluginCall call) {
    String text = call.getString("text");
    String target = call.getString("target");
    if (text == null || target == null || text.trim().isEmpty()) {
      call.reject("texto o idioma incompleto");
      return;
    }
    identifyAndTranslate(call, text, target);
  }

  private void identifyAndTranslate(PluginCall call, String text, String target) {
    LanguageIdentifier identifier = LanguageIdentification.getClient();
    identifier.identifyLanguage(text).addOnSuccessListener(source -> {
      identifier.close();
      if (source == null || source.equals("und")) {
        // Las líneas cortas de canciones no siempre se pueden identificar.
        // La mayoría de las letras que llegan a esta app están en inglés.
        translateWithSource(call, text, "en", target);
      } else {
        translateWithSource(call, text, source, target);
      }
    }).addOnFailureListener(e -> {
      identifier.close();
      // No bloquear toda la traducción por un fallo puntual del identificador.
      translateWithSource(call, text, "en", target);
    });
  }

  private void translateWithSource(PluginCall call, String text, String source, String target) {
    if (source.equals(target)) {
      JSObject result = new JSObject();
      result.put("text", text);
      call.resolve(result);
      return;
    }
    TranslatorOptions options = new TranslatorOptions.Builder()
        .setSourceLanguage(source)
        .setTargetLanguage(target)
        .build();
    Translator translator = Translation.getClient(options);
    DownloadConditions conditions = new DownloadConditions.Builder().build();
    translator.downloadModelIfNeeded(conditions)
        .addOnSuccessListener(v -> translator.translate(text)
            .addOnSuccessListener(translated -> {
              JSObject result = new JSObject();
              result.put("text", translated);
              call.resolve(result);
              translator.close();
            })
            .addOnFailureListener(e -> {
              call.reject("falló la traducción: " + e.getMessage());
              translator.close();
            }))
        .addOnFailureListener(e -> {
          call.reject("no se pudo descargar el modelo: " + e.getMessage());
          translator.close();
        });
  }
}
