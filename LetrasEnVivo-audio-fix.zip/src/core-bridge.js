import { registerPlugin } from '@capacitor/core';

window.LV = window.LV || {};
window.LV.MediaSession = registerPlugin('MediaSession');
window.LV.LocalNotifications = registerPlugin('LocalNotifications');
window.LV.Filesystem = registerPlugin('Filesystem');
window.LV.Share = registerPlugin('Share');
window.LV.MusicScan = registerPlugin('MusicScan');
window.LV.LocalTranslate = registerPlugin('LocalTranslate');
