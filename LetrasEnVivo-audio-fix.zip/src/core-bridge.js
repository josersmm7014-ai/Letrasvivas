import { registerPlugin } from '@capacitor/core';

window.LV = window.LV || {};
const use = (name) => window.LV[name] || registerPlugin(name);
window.LV.MediaSession = use('MediaSession');
window.LV.LocalNotifications = use('LocalNotifications');
window.LV.Filesystem = use('Filesystem');
window.LV.Share = use('Share');
window.LV.MusicScan = use('MusicScan');
window.LV.LocalTranslate = use('LocalTranslate');
