import { registerPlugin } from '@capacitor/core';
import { MediaSession } from '@jofr/capacitor-media-session';
import { LocalNotifications } from '@capacitor/local-notifications';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
const MusicScan = registerPlugin('MusicScan');
const LocalTranslate = registerPlugin('LocalTranslate');
window.LV = { MediaSession, LocalNotifications, Filesystem, Directory, Share, MusicScan, LocalTranslate };
