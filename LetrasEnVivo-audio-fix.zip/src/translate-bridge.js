import { registerPlugin } from '@capacitor/core';
window.LV = window.LV || {};
window.LV.LocalTranslate = window.LV.LocalTranslate || registerPlugin('LocalTranslate');
