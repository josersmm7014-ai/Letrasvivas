#!/bin/bash
set -e
cd app
npm install --legacy-peer-deps
npx esbuild src/bridge.js --bundle --minify --format=iife --outfile=www/bridge-v3.js
npx cap add android
printf '%s\n' '    implementation "com.google.mlkit:translate:17.0.3"' '    implementation "com.google.mlkit:language-id:17.0.5"' | sed -i '/dependencies {/r /dev/stdin' android/app/build.gradle
cp -r res/. android/app/src/main/res/
printf '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n<color name="ic_launcher_background">#0A0612</color>\n</resources>\n' > android/app/src/main/res/values/ic_launcher_background.xml
cp native/*.java android/app/src/main/java/com/letras/envivo/
PERMS='<uses-permission android:name="android.permission.FOREGROUND_SERVICE" /><uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" /><uses-permission android:name="android.permission.POST_NOTIFICATIONS" /><uses-permission android:name="android.permission.WAKE_LOCK" /><uses-permission android:name="android.permission.READ_MEDIA_AUDIO" /><uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />'
sed -i "s#<application#${PERMS}\n<application#" android/app/src/main/AndroidManifest.xml
npx cap sync android
cd android
chmod +x gradlew
./gradlew assembleDebug
